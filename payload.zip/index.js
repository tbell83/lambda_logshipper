'use strict';
console.log('Loading function');
const aws = require('aws-sdk');
const s3 = new aws.S3({ apiVersion: '2006-03-01' });

exports.handler = (event, context, callback) => {
    const sourceBucket = event.Records[0].s3.bucket.name;
    const sourceKey = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));
    var targetBucket = process.env.TARGET_BUCKET + '/' + process.env.TARGET_PATH
    var targetAcl = process.env.TARGET_ACL

    s3.copyObject(
        {
            CopySource: sourceBucket + '/' + sourceKey,
            Bucket: targetBucket,
            Key: sourceKey,
            ACL: targetAcl
        },
        function (copyErr, copyData) {
            if (copyErr) {
                console.log('Error: ' + copyErr);
            } else {
                console.log('Copied ' + sourceKey + ' to ' + targetBucket + ' OK');
            }
        }
    );
    callback(null, 'All done!');
};